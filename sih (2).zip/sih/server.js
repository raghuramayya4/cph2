// server.js
const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Mock Data for Projects and Students
const projects = [
    {
        project: {
            title: 'AI-Based Health Monitoring',
            type: 'Machine Learning',
            description: 'A project focused on using AI for real-time health monitoring and diagnostics.'
        },
        student: {
            name: 'John Doe',
            branch: 'Computer Science',
            teamMembers: ['Alice Smith', 'Bob Johnson', 'Eve Williams']
        }
    },
    {
        project: {
            title: 'Smart Home Automation',
            type: 'IoT',
            description: 'An IoT-based project that automates home appliances using a smart app.'
        },
        student: {
            name: 'Jane Doe',
            branch: 'Electronics',
            teamMembers: ['Tom Hardy', 'Emma Clark']
        }
    }
];

// Endpoint to fetch all projects and corresponding student profiles
app.get('/projects', (req, res) => {
    res.json(projects);
});

// Endpoint to add a new project and student profile (optional for testing)
app.post('/projects', (req, res) => {
    const newProject = req.body;
    if (newProject.project && newProject.student) {
        projects.push(newProject);
        res.status(201).json({ message: 'Project added successfully!' });
    } else {
        res.status(400).json({ error: 'Invalid project or student data' });
    }node
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
